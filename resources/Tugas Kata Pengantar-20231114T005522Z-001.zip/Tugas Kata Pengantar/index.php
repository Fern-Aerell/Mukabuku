<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <h1>KATA PENGANTAR</h1>
    <br>
    <div class="content">
        <p class="jarak">Segala puji syukur kepada Tuhan Yang Maha Esa karena berkat rahmatNya penulisan
            modul Mata Kuliah Web Programming II dapat terselesaikan dengan baik. Modul ini disusun
            untuk memenuhi kebutuhan mahasiswa dalam mata kuliah Web Programming II yang
            disajikan dalam bentuk praktikum dan diharapkan dapat membekali mahasiswa dalam
            memahami Pembuatan web dengan menggunakan Framework Codeigniter.</p>

        <p class="jarak">Modul web Programming II materi bahasan dibatasi sampai dengan halaman
            Administrator (Back-End). Diakhir perkuliahan mahasiswa diharapkan mampu
            mengimplementasikannya dalam bentuk final project yang harus dipresentasikan sebagai
            syarat kelulusan mata kuliah Web Programming II. Teknik penyajiannya dilakukan secara
            terpadu dan sistematis.</p>

        <p class="jarak">Seperti layaknya sebuah modul, maka pembahasan dimulai dengan menjelaskan target
            pembelajaran yang hendak dicapai. Dengan demikian pengguna modul ini secara mandiri
            dapat mengukur tingkat ketuntasan yang dicapainya.</p>


        <p class="jarak">Penulis menyadari sepenuhnya bahwa modul ini tentu memiliki banyak kekurangan. Untuk itu
            penulis dengan lapang dada menerima masukan dan kritik yang konstruktif dari
            berbagai pihak demi kesempurnaannya di masa yang akan datang. Semoga modul ini dapat
            bermanfaat bagi para pembaca.</p>

    </div>

    <div class="footer">
        <span>Padang, Januari 2022</span>
        <span>Tim Penulis</span>
    </div>
</body>

</html>